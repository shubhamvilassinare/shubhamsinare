proxyClaims {
    // Na proxyClaims pišeš atribute, ki bodo prisotni v generiranem tokenu. Po defaultu že doda vse iz distContext
    proxyClaims["aud"] = setOf("auth-proxy", "account")

    // Prebere atribut na iz distContext na podlagi katerega doda role v končni token.
    // Ponavadi nekaj v stilu "user_roles" ali "roles".
    // TODO: HSE needs to decide where to get user roles from for real users
    val userRoles = distContext.readSet("user_role", String::class)
    logger.debug { "Fixed claims user roles: $userRoles" }

    if ("service-account-auth-broker" in userRoles) {
        // dodaj te role na končni token. Prvi argument je client, drugo so role
        addRoles("portal", "SYS_ADMIN")
        addRoles("ehr", "ROLE_ADMIN")
        addRoles("demographics", "DEMOGRAPHICS_ADMIN")
    }
    if ("service-account-dist-token" in userRoles) {
        addRoles("portal", "SERVICE_ACCOUNT")
        addRoles("demographics", "DEMOGRAPHICS_READ", "DEMOGRAPHICS_SEARCH", "DEMOGRAPHICS_WRITE")
    }
    if (userRoles.isEmpty()) {
        // TODO: HSE needs to decide how to handle roles for real users, so for now we give everyone read access
        // For now the same roles as GROUP NSCR_USER on keycloak
        addRoles("demographics", "DEMOGRAPHICS_LOCATION_HIERARCHY", "DEMOGRAPHICS_WRITE", "DEMOGRAPHICS_SEARCH", "DEMOGRAPHICS_READ", "DEMOGRAPHICS_EXTENDED_OPERATION")
        addRoles("ehr", "ROLE_READ", "ROLE_VIEW", "ROLE_QUERY")
        addRoles("portal", "PATHFINDER_PATIENT_MARK_AS_MINE", "PATHFINDER_EHRFORM_READ", "PATHFINDER_PATIENT_READ")
    }
}
