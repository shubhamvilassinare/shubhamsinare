proxyClaims {
    // Na proxyClaims pišeš atribute, ki bodo prisotni v generiranem tokenu. Po defaultu že doda vse iz distContext
    proxyClaims["aud"] = setOf("auth-proxy", "account")

    val GROUP_NSCR_ADMIN = "S-UG-DEV-NSCR-ADMIN"
    val GROUP_NSCR_USER  = "S-UG-DEV-NSCR-User"

    fun addAdminRoles() {
        // Same roles as GROUP BETTER_ADMIN on keycloak
        addRoles(
            "demographics",
            "DEMOGRAPHICS_WRITE", "DEMOGRAPHICS_EXTENDED_OPERATION", "DEMOGRAPHICS_ADMIN_TENANT",
            "DEMOGRAPHICS_SEARCH", "DEMOGRAPHICS_CREATE", "DEMOGRAPHICS_LOCATION_HIERARCHY",
            "DEMOGRAPHICS_ADMIN_INDEX", "DEMOGRAPHICS_READ", "DEMOGRAPHICS_ADMIN"
        )
        addRoles(
            "portal",
            "PATHFINDER_EHRFORM_WRITE", "PATHFINDER_USERMANAGEMENT_FULL", "PATHFINDER_PATIENT_WRITE",
            "AUDIT_TRAIL_EXPORT", "PATHFINDER_EHRFORM_READ", "AUDIT_TRAIL_READ",
            "PATHFINDER_PATIENT_READ", "PATHFINDER_PATIENT_MARK_AS_MINE", "PATHFINDER_PATIENT_ALLERGIES_READ"
        )
        addRoles("ehr", "ROLE_WRITE", "ROLE_ADMIN", "ROLE_READ")
        addRoles("auditor", "AUDIT_TRAIL_READ", "AUDIT_TRAIL_EXPORT")
        addRoles("user-management", "ROLE_USER", "ROLE_ADMIN")
        addRoles("realm-management", "realm-admin")
        addRoles("settings", "SETTINGS_NOTIFICATION_ADMIN", "SETTINGS_ADMIN")
    }

    fun addUserRoles() {
        // Same roles as GROUP NSCR_USER on keycloak
        addRoles(
            "demographics",
            "DEMOGRAPHICS_LOCATION_HIERARCHY", "DEMOGRAPHICS_SEARCH", "DEMOGRAPHICS_READ",
            "DEMOGRAPHICS_EXTENDED_OPERATION_META_DELETE", "DEMOGRAPHICS_EXTENDED_OPERATION_META_ADD"
        )
        addRoles("ehr", "ROLE_READ", "ROLE_VIEW", "ROLE_QUERY")
        addRoles("portal", "PATHFINDER_PATIENT_MARK_AS_MINE", "PATHFINDER_EHRFORM_READ", "PATHFINDER_PATIENT_READ", "NSCR_USER")
        addRoles("auditor", "AUDIT_TRAIL_READ")
    }

    val userGroups = distContext.readSet("idp_groups", String::class)
    logger.debug { "Fixed groups for user: $userGroups" }

    if (userGroups.isNotEmpty()) {
        if (GROUP_NSCR_ADMIN in userGroups) {
            addAdminRoles()
        } else if (GROUP_NSCR_USER in userGroups) {
            addUserRoles()
        } else {
            addUserRoles()
        }
    } else {
        // TODO: HSE needs to decide how to handle roles for real users, so for now we give everyone read access
        // For now the same roles as GROUP NSCR_USER on keycloak
        addUserRoles()
    }
}