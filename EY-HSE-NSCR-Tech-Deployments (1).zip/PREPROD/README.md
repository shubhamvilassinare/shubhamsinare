# HSE-PREPROD Environment Configuration

This directory contains the user-friendly configuration for the HSE-PREPROD environment.

## 📁 Files you can manage:

### 1. `versions.env` - Application Versions
Simple key=value format for application versions:
```
abac=2.0.6
auditor=2.0.3
dashboard=1.2.0
ehr=4.4.6
...
```

### 2. `resources.env` - Resource Limits
Memory and CPU limits for each service:
```
abac_memory=1Gi
abac_cpu=500m
ehr_memory=2Gi
ehr_cpu=1000m
...
```

### 3. `configs/` folder - Application Configurations
Service-specific configuration files:
- `configs/abac/` - ABAC service configuration
- `configs/auditor/` - Auditor service configuration
- `configs/ehr/` - EHR service configuration
- etc.

### 4. `cronjobs/` folder - Scheduled Jobs
Manage scheduled tasks:
- `daily-cleanup.yaml` - Daily cleanup job
- `weekly-reports.yaml` - Weekly reports job
- `templates/` - Templates for creating new jobs

## 🚫 What you DON'T need to touch:
- `kustomization.yaml` - Technical Kubernetes configuration (managed by PREPRODOps)

## 🔄 How to make changes:

### Update Application Versions:
1. Edit `versions.env`
2. Change the version number for any application
3. Deploy using your standard process

### Adjust Resource Limits:
1. Edit `resources.env`
2. Modify memory/CPU values as needed
3. Deploy to apply changes

### Update Application Configs:
1. Navigate to `configs/[service-name]/`
2. Edit configuration files (application.yml, log4j2.xml, etc.)
3. Deploy to apply changes

### Add/Modify CronJobs:
1. Copy `cronjobs/templates/cronjob-template.yaml`
2. Rename and customize for your needs
3. Add the new file to `cronjobs/kustomization.yaml`
4. Deploy to create the scheduled job

## 📊 Monitoring CronJobs:
- View jobs: `kubectl get cronjobs -n hse-PREPROD`
- View job history: `kubectl get jobs -n hse-PREPROD`
- View logs: `kubectl logs job/job-name -n hse-PREPROD`