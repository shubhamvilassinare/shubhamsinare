proxyClaims {
    proxyClaims["aud"] = listOf("auth-proxy", "ehr", "demographics")

    addRoles("ehr", "PATIENT_SELF", "ROLE_VIEW")
}