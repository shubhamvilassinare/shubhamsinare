flows {
    // definira en flow
    // če imaš več flowov v enem tenanti, lahko izbereš katerega boš uporabil z ?flow=<NAME>
    tokenFlow("token") {
        public = true
        // zahteva JWT token, ki ga validira s tem servisom
        // zgornji primer pričakuje token v Dit-Local-Token headerju, če ga hočeš podati drugače, lahko poveš v body od kje naj se prebere.
         loginOauth2("keycloakIdProvider") {
             // to prebere iz Dist-Access-Token headerja, je samo shorthand za:
             // broker.request.headers["Dist-Access-Token", String::class]?.let  { JWT.fromString(it) }
             JWT.accessToken()
         }

        distContext {
            // kateri atributi naj se zapišejo v diagnostics log. Zapišejo se samo tisi ki se dodajo v distContext
            loggedAttributes.plain += setOf(
                "patient_id", "organization", "practiceSetting", "patient_tzo", "ehr_id", "externalId",
                "externalIdWithOrg", "user_role_org", "practiceSetting", "idp_groups")

            // Pri JWT avtentikaciji so claimi input tokena v loginResult.oauth2.claims
            val claims = loginResult.oauth2.claims

            // kopira vse claime iz input tokena v distContext
            distContext += claims
        }
    }

}


