flows {
    tokenFlow("hse-app") {
        loginOauth2("hse-app") {
            JWT.accessToken()
        }

        distContext {
            loggedAttributes.hashed += setOf("patient_ihi")
            loggedAttributes.plain += setOf("patient_ehr_id")

            val claims = loginResult.oauth2.claims
            val ihi: String = claims["sub", String::class]
                ?: throwHttpStatusException(401, "missing_claim_sub")

            val ihiSystem = "IHI"

            val ehr = try {
                withEhr { api().retrieveEhr(ihi, ihiSystem) }
            } catch (e: Exception) {
                logger.debug(e) { "No EHR for IHI: $${e.message}" }
                throwHttpStatusException(404, "patient_not_registered")
            }

            distContext["patient_ihi"] = ihi
            distContext["patient_ehr_id"] = ehr.ehrId
        }
    }
}