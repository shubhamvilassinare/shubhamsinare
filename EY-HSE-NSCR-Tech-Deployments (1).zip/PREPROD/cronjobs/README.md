# CronJobs Management

This directory allows you to manage scheduled jobs in Kubernetes.

## Existing CronJobs

- `daily-cleanup.yaml` - Runs daily at 2 AM for cleanup tasks
- `weekly-reports.yaml` - Runs every Monday at 8 AM for reports

## Adding New CronJobs

1. Copy `templates/cronjob-template.yaml` to a new file
2. Replace placeholders:
   - `JOBNAME` - Your job name (lowercase, no spaces)
   - `SCHEDULE` - Cron schedule expression
   - Add your commands in the script section
3. The new cronjob will be automatically deployed

## Cron Schedule Format

```
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of week (0 - 6) (Sunday to Saturday)
│ │ │ │ │
* * * * *
```

## Common Examples

- `"0 2 * * *"` - Daily at 2 AM
- `"0 */6 * * *"` - Every 6 hours
- `"0 8 * * 1"` - Every Monday at 8 AM
- `"0 0 1 * *"` - First day of every month
- `"*/15 * * * *"` - Every 15 minutes

## Managing CronJobs

- **View running jobs**: `kubectl get cronjobs -n hse-preprod`
- **View job history**: `kubectl get jobs -n hse-preprod`
- **View job logs**: `kubectl logs job/job-name -n hse-preprod`
- **Delete a cronjob**: Remove the YAML file and redeploy