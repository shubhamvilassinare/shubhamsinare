#!/usr/bin/env bash
set -euo pipefail

echo "##[command]### Deploying kube-prometheus-stack"

# --- CONFIG / ENV ---
NAMESPACE="monitoring"
RELEASE="kube-prometheus-stack"
CHART="oci://eyctpeu-nscr-jfrog-artifactory-docker-prod.jfrog.io/external-url/helm/kube-prometheus-stack"
CHART_VERSION="79.5.0"

VALUES_DIR="kube-prometheus-stack"
VALUES_FILE="${VALUES_DIR}/kube-prometheus-stack-helm-values.yaml"
PROM_CR_FILE="${VALUES_DIR}/prometheus-cr.yaml"
RENDERED_VALUES_FILE="${VALUES_DIR}/.rendered-values.yaml"
RENDERED_PROM_FILE="${VALUES_DIR}/.rendered-prometheus-cr.yaml"

# Fallbacks
MONITORING_STORAGE_CLASS="${MONITORING_STORAGE_CLASS:-managed-csi}"
MONITORING_STORAGE_SKU="${MONITORING_STORAGE_SKU:-StandardSSD_LRS}"
echo "Using StorageClass=${MONITORING_STORAGE_CLASS}, SKU=${MONITORING_STORAGE_SKU}"

# echo "ENV VALUE: $ENVIRONMENT"
# echo "PWD BEFORE CD: $(pwd)"
# echo "Listing ado-deploy:"
# ls -l $BUILD_SOURCESDIRECTORY/ado-deploy

# ENV=$(echo "$ENVIRONMENT" | tr '[:lower:]' '[:upper:]')
# cd $BUILD_SOURCESDIRECTORY/ado-deploy/$ENV/components/monitoring/

# --- cd to monitoring component dir ---
ENV=$(echo "$ENVIRONMENT" | tr '[:lower:]' '[:upper:]')
cd $BUILD_SOURCESDIRECTORY/ado-deploy/$ENV/components/monitoring/

# --- 1) Namespace ---
kubectl apply -f namespace.yaml
kubectl label ns "${NAMESPACE}" pod-security.kubernetes.io/enforce=privileged --overwrite

# --- Ensure imagePullSecret exists in monitoring namespace ---
# echo "[INFO] Ensuring image pull secret exists in '${NAMESPACE}' namespace..."

# SECRET_NAME="nscr-jfrog-artifactory"

# Try to find the secret in all namespaces
# SOURCE_NS=$(kubectl get secret -A | grep -m1 "${SECRET_NAME}" | awk '{print $1}' || true)

# if [[ -z "$SOURCE_NS" ]]; then
#     echo "[ERROR] Secret '${SECRET_NAME}' not found in ANY namespace!"
#     echo "Create it manually or supply REGISTRY credentials to the pipeline."
#     exit 1
# fi

# if kubectl get secret "${SECRET_NAME}" -n "${NAMESPACE}" >/dev/null 2>&1; then
#     echo "[INFO] ImagePullSecret '${SECRET_NAME}' already exists in '${NAMESPACE}', skipping copy."
# else
#     echo "[INFO] Copying secret '${SECRET_NAME}' from namespace '${SOURCE_NS}' to '${NAMESPACE}'..."
#     kubectl get secret "${SECRET_NAME}" -n "${SOURCE_NS}" -o yaml \
#       | sed "s/namespace: ${SOURCE_NS}/namespace: ${NAMESPACE}/" \
#       | kubectl apply -f -
#     echo "[INFO] Secret copied successfully."
# fi

# --- 2) StorageClass (optional create from template) ---
if kubectl get sc "${MONITORING_STORAGE_CLASS}" >/dev/null 2>&1; then
    echo "[INFO] StorageClass ${MONITORING_STORAGE_CLASS} exists; skipping."
else
    echo "[INFO] Creating StorageClass ${MONITORING_STORAGE_CLASS} (SKU=${MONITORING_STORAGE_SKU})"
    sed "s/{{SC_NAME}}/${MONITORING_STORAGE_CLASS}/; s/{{SC_SKU}}/${MONITORING_STORAGE_SKU}/" \
    kube-prometheus-stack/storageclass.yaml | kubectl apply -f -
fi

# --- 3) Chart Source: JFrog OCI Registry ---

# --- 4) Render Helm values ---
if command -v envsubst >/dev/null; then
    envsubst < "${VALUES_FILE}" > "${RENDERED_VALUES_FILE}"
    USE_VALUES="${RENDERED_VALUES_FILE}"
else
    USE_VALUES="${VALUES_FILE}"
fi

# --- 5) Install / upgrade chart (Operator + CRDs, Prometheus disabled) ---
echo -e "\nInstalling kube-prometheus-stack Helm Chart\n"
helm upgrade -i "${RELEASE}" "${CHART}" \
    -n "${NAMESPACE}" \
    -f "${USE_VALUES}" \
    --set crds.enabled=true \
    --version "${CHART_VERSION}"

echo "[INFO] Waiting for CRDs to be established..."
kubectl wait --for=condition=Established crd/prometheuses.monitoring.coreos.com --timeout=2m
kubectl wait --for=condition=Established crd/alertmanagers.monitoring.coreos.com --timeout=2m
kubectl wait --for=condition=Established crd/servicemonitors.monitoring.coreos.com --timeout=2m
kubectl wait --for=condition=Established crd/podmonitors.monitoring.coreos.com --timeout=2m

# --- 6) Wait for Prometheus Operator ---
echo "[INFO] Waiting for Prometheus Operator to be ready..."
kubectl rollout status deploy "${RELEASE}-operator" -n "${NAMESPACE}" --timeout=5m || true
#\ kubectl rollout status deploy "${RELEASE}-operator" -n "${NAMESPACE}" --timeout=5m || true

# --- 7) Apply Prometheus CR ---
if command -v envsubst >/dev/null; then
    NAMESPACE="${NAMESPACE}" MONITORING_STORAGE_CLASS="${MONITORING_STORAGE_CLASS}" \
    envsubst < "${PROM_CR_FILE}" > "${RENDERED_PROM_FILE}"
    echo "[INFO] Skipping external Prometheus CR (using Helm-managed Prometheus)"
#    kubectl apply -f "${RENDERED_PROM_FILE}"
else
    kubectl apply -f "${PROM_CR_FILE}"
fi

echo "===== DEBUG: POD STATUS ====="
kubectl get pods -n "${NAMESPACE}" || true

echo "===== DEBUG: DESCRIBE PODS ====="
kubectl describe pods -n "${NAMESPACE}" || true

echo "===== DEBUG: EVENTS ====="
kubectl get events -n "${NAMESPACE}" --sort-by=.metadata.creationTimestamp || true

# --- 8) Wait for Prometheus StatefulSet ---
echo "[INFO] Waiting for Prometheus StatefulSet..."

PROM_STS=$(kubectl get sts -n "${NAMESPACE}" \
  --no-headers | grep prometheus | awk '{print $1}' || true)

if [[ -z "${PROM_STS}" ]]; then
    echo "[WARN] Prometheus StatefulSet not found in '${NAMESPACE}', skipping wait..."
else
    kubectl rollout status sts "${PROM_STS}" -n "${NAMESPACE}" --timeout=10m || true
fi


# --- 9) Wait for Prometheus pod readiness ---
echo "[INFO] Locating Prometheus pod..."

PROM_POD=$(kubectl get pods -n "${NAMESPACE}" \
  --no-headers | grep prometheus | awk '{print $1}' || true)

if [[ -z "${PROM_POD}" ]]; then
    echo "[WARN] Prometheus pod not found, skipping readiness wait..."
    kubectl get pods -n "${NAMESPACE}"
else
    echo "[INFO] Waiting for Prometheus pod readiness..."
    kubectl wait --for=condition=Ready pod "${PROM_POD}" -n "${NAMESPACE}" --timeout=300s || true
    echo "[INFO] Prometheus is ready."
fi

echo "[INFO] Applying Prometheus alert rules..."
RULES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for rule_file in "$RULES_DIR"/general-rules.yaml "$RULES_DIR"/kubernetes-apps.yaml "$RULES_DIR"/kubernetes-storage.yaml; do
    if [[ -f "$rule_file" ]]; then
        echo "[INFO] Applying $(basename "$rule_file")"
        kubectl apply -f "$rule_file" -n "${NAMESPACE}"
    else
        echo "[WARN] File not found: $rule_file"
    fi
done
echo "[INFO] Verifying PrometheusRule resources..."
kubectl get prometheusrules -n "${NAMESPACE}"

# --- 10) Summary ---
echo -e "\n[INFO] kube-prometheus-stack deployment completed."
kubectl get pods -n "${NAMESPACE}"
kubectl get svc -n "${NAMESPACE}"
kubectl get sts -n "${NAMESPACE}"