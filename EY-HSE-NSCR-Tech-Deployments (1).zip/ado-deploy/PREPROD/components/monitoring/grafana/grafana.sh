#!/usr/bin/env bash
set -euo pipefail


DEBUG="${DEBUG:-false}"

debug() {
  [[ "$DEBUG" == "true" ]] && echo "[DEBUG] $*"
}

log()   { echo "[INFO] $*"; }
error() { echo "[ERROR] $*"; exit 1; }

if [[ "$DEBUG" == "true" ]]; then
  set -x  # print every executed command
fi


log()   { echo "[INFO] $*"; }
error() { echo "[ERROR] $*"; exit 1; }

# --- CONFIG ---
NAMESPACE="monitoring"
RELEASE="grafana"
CHART="oci://eyctpeu-nscr-jfrog-artifactory-docker-prod.jfrog.io/external-url/helm/grafana"
CHART_VERSION="10.2.0"
STORE="azure-kv-azure-managed-identity"
AUTH_SECRET="pprd-grafana-auth"
BASE_DIR="${BUILD_SOURCESDIRECTORY}/ado-deploy/${ENVIRONMENT}/components/monitoring/grafana"
VALUES_FILE="${BASE_DIR}/grafana-helm-values.yaml"
EXT_SECR_FILE="${BASE_DIR}/grafana-externalsecret.yaml"
INGRESS_FILE="${BASE_DIR}/ingress.yaml"
DASH_DIR="${BASE_DIR}/dashboards"
ALERTING_CONFIGMAP="${BASE_DIR}/grafana-alerting-configmap.yaml"

# --- BIN bootstrap ---
BIN_DIR="${AGENT_TEMPDIRECTORY:-/tmp}/bin"; export PATH="$BIN_DIR:$PATH"; mkdir -p "$BIN_DIR"
command -v yq >/dev/null || { log "Installing yq"; curl -fsSL -o "$BIN_DIR/yq" https://github.com/mikefarah/yq/releases/download/v4.44.3/yq_linux_amd64 && chmod +x "$BIN_DIR/yq"; }
command -v jq >/dev/null || { log "Installing jq"; curl -fsSL -o "$BIN_DIR/jq" https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64 && chmod +x "$BIN_DIR/jq"; }

# --- VALIDATION ---
for f in "$VALUES_FILE" "$EXT_SECR_FILE" "$INGRESS_FILE" "$ALERTING_CONFIGMAP" ; do
  [[ -f "$f" ]] || error "Missing file: $f"
done

# --- Namespace ---
kubectl create ns "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# --- Helm chart source: JFrog OCI registry login done by the pipeline step ---

# --- Ensure ESO store exists ---
kubectl get clustersecretstore "$STORE" >/dev/null 2>&1 || error "ClusterSecretStore '$STORE' not found"

# Apply ExternalSecret and force resync
kubectl apply -f "$EXT_SECR_FILE"
kubectl -n "$NAMESPACE" annotate externalsecret "$AUTH_SECRET" external-secrets.io/force-sync="$(date +%s)" --overwrite || true

# Wait for secret
for i in {1..60}; do
  kubectl -n "$NAMESPACE" get secret "$AUTH_SECRET" &>/dev/null && break
  sleep 2
done
kubectl -n "$NAMESPACE" get secret "$AUTH_SECRET" &>/dev/null || error "'$AUTH_SECRET' not re-created"

# Validate required keys
required_keys=(CLIENT_ID CLIENT_SECRET AZURE_TENANT_ID GF_SECURITY_ADMIN_USER GF_SECURITY_ADMIN_PASSWORD)
missing=()
for k in "${required_keys[@]}"; do
  v="$(kubectl -n "$NAMESPACE" get secret "$AUTH_SECRET" -o jsonpath="{.data.$k}" 2>/dev/null || true)"
  [[ -n "$v" ]] || missing+=("$k")
done
(( ${#missing[@]} == 0 )) || error "Secret '$AUTH_SECRET' missing keys: ${missing[*]}"

# --- Apply ConfigMaps ---
log "Applying Grafana alerting ConfigMap..."
kubectl apply -f "$ALERTING_CONFIGMAP"

# --- Clean old pods ---
log "Cleaning up old Grafana pods..."
kubectl -n "$NAMESPACE" delete pod -l app.kubernetes.io/name=grafana --ignore-not-found
kubectl -n "$NAMESPACE" wait --for=delete pod -l app.kubernetes.io/name=grafana --timeout=60s || true

# --- StorageClass and PVC Setup ---
GRAFANA_STORAGE_CLASS="${GRAFANA_STORAGE_CLASS:-managed-csi}"
GRAFANA_STORAGE_SKU="${GRAFANA_STORAGE_SKU:-StandardSSD_LRS}"
PVC_NAME="${PVC_NAME:-grafana-pvc}"
PVC_FILE="${BASE_DIR}/grafana-storageclass.yaml"

log "Using StorageClass=${GRAFANA_STORAGE_CLASS}, SKU=${GRAFANA_STORAGE_SKU}"

# --- StorageClass and PVC Setup ---
GRAFANA_STORAGE_CLASS="${GRAFANA_STORAGE_CLASS:-managed-csi}"
GRAFANA_STORAGE_SKU="${GRAFANA_STORAGE_SKU:-StandardSSD_LRS}"

PVC_NAME="${PVC_NAME:-grafana-pvc}"
GRAFANA_SC_FILE="${BASE_DIR}/grafana-storageclass.yaml"   # template with {{GRAFANA_STORAGE_CLASS}} and {{GRAFANA_STORAGE_SKU}}
PVC_FILE="${BASE_DIR}/grafana-pvc.yaml"                   # concrete PVC manifest (no inline generation)

log "Using StorageClass=${GRAFANA_STORAGE_CLASS}, SKU=${GRAFANA_STORAGE_SKU}"

# StorageClass (create if missing)
if kubectl get sc "${GRAFANA_STORAGE_CLASS}" >/dev/null 2>&1; then
  log "StorageClass ${GRAFANA_STORAGE_CLASS} exists; skipping."
else
  [[ -f "${GRAFANA_SC_FILE}" ]] || error "StorageClass template not found: ${GRAFANA_SC_FILE}"
  log "Creating StorageClass ${GRAFANA_STORAGE_CLASS} (SKU=${GRAFANA_STORAGE_SKU})"
  sed "s/{{GRAFANA_STORAGE_CLASS}}/${GRAFANA_STORAGE_CLASS}/; s/{{GRAFANA_STORAGE_SKU}}/${GRAFANA_STORAGE_SKU}/" \
    "${GRAFANA_SC_FILE}" | kubectl apply -f -
fi

# PVC (create if missing; require external YAML, do NOT hardcode)
if kubectl -n "${NAMESPACE}" get pvc "${PVC_NAME}" >/dev/null 2>&1; then
  log "PVC ${PVC_NAME} exists; skipping."
else
  [[ -f "${PVC_FILE}" ]] || error "PVC definition file not found: ${PVC_FILE}. Pipeline will fail."
  log "Creating PVC from ${PVC_FILE}"
  kubectl apply -f "${PVC_FILE}"
fi


# --- Deploy Grafana ---
log "Deploying Grafana Helm chart..."
helm upgrade -i "$RELEASE" "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES_FILE" \
  --version "$CHART_VERSION" \
  --set initChownData.enabled=false \
  --set podSecurityContext.runAsUser=1000 \
  --set podSecurityContext.runAsGroup=1000 \
  --set podSecurityContext.fsGroup=1000 \
  --set securityContext.runAsNonRoot=false \
  --set envFromSecret="$AUTH_SECRET" || error "Helm upgrade failed"

# --- Restart Grafana ---
log "Restarting Grafana deployment..."
kubectl rollout restart deploy/grafana -n "$NAMESPACE"
kubectl rollout status deploy/grafana -n "$NAMESPACE" --timeout=120s || error "Grafana rollout did not finish in time"

# --- Ingress ---
kubectl delete ingress "$RELEASE" -n "$NAMESPACE" --ignore-not-found
kubectl apply -f "$INGRESS_FILE"

# --- CLEAN OLD DASHBOARDS ---
log "Deleting old dashboard ConfigMaps..."
kubectl get cm -A -l grafana_dashboard=1 -o json | jq -r '.items[] | "\(.metadata.namespace) \(.metadata.name)"' | \
while read ns name; do
  log "Deleting old dashboard ConfigMap: $ns/$name"
  kubectl delete cm -n "$ns" "$name" --ignore-not-found
done

# --- Self-correcting check: ensure Viewer/Editor folders hold the right content ---
log "Checking Viewer/Editor folder content is correctly assigned..."

CHECK_FILE="${DASH_DIR}/Viewer/nscr-home.json"
if [[ -f "${CHECK_FILE}" ]]; then
    CHECK_TITLE=$(python3 -c "import json; print(json.load(open('${CHECK_FILE}')).get('title',''))" 2>/dev/null || echo "")
    if [[ "${CHECK_TITLE}" == "NSCR Home" ]]; then
        log "Viewer/Editor content is backwards (found NSCR Home in Viewer/) — auto-correcting..."
        TMP_DIR=$(mktemp -d)
        mv "${DASH_DIR}"/Viewer/*.json "${TMP_DIR}/"
        mv "${DASH_DIR}"/Editor/*.json "${DASH_DIR}/Viewer/"
        mv "${TMP_DIR}"/*.json "${DASH_DIR}/Editor/"
        rmdir "${TMP_DIR}"
        log "Auto-correction applied for this run."
    else
        log "Viewer/Editor content already correct, no action needed."
    fi
else
    log "Check file not found at expected path, skipping auto-correction check."
fi

# --- Apply dashboards ---
log "Applying new dashboards..."
if find "$DASH_DIR" -name "*.json" | grep -q .; then
  find "$DASH_DIR" -name "*.json" | while read -r file; do
    rel_dir="$(dirname "${file#$DASH_DIR/}")"
    if [[ "$rel_dir" == "." ]]; then
      error "Dashboard file $file is not inside a subfolder of $DASH_DIR. Place it under a subfolder named after its target Grafana folder, e.g. dashboards/Kubernetes/${file##*/}"
    fi
    folder="$rel_dir"
    name="grafana-dashboard-$(basename "$file" .json | tr '[:upper:]' '[:lower:]' | tr -c 'a-z0-9-' '-' | sed -E 's/^-+//; s/-+$//')"    
    log "Applying $file -> ConfigMap $name -> folder '$folder'"
    kubectl create configmap "$name" -n "$NAMESPACE" --from-file="$file" --dry-run=client -o yaml | kubectl apply -f -
    kubectl patch configmap "$name" -n "$NAMESPACE" --type merge \
      -p "{\"metadata\":{\"labels\":{\"grafana_dashboard\":\"1\"},\"annotations\":{\"grafana_folder\":\"${folder}\"}}}"
  done
fi

log "✅ Grafana redeploy completed with clean dashboards, alerting, and variables applied."

echo "================================"
echo "Executing Grafana RBAC"
echo "================================"

RBAC_DIR="${BASE_DIR}/rbac"

RBAC_SCRIPT="${RBAC_DIR}/grafana-rbac.sh"

echo "Listing RBAC directory..."
ls -ltr "${RBAC_DIR}"

chmod +x "${RBAC_SCRIPT}"

cd "${RBAC_DIR}"

echo "Running grafana-rbac.sh"
./grafana-rbac.sh

echo "================================"
echo "Grafana RBAC Finished"
echo "================================"

echo "================================"
echo "Executing Grafana TEAM RBAC"
echo "================================"

TEAM_RBAC_SCRIPT="${RBAC_DIR}/grafana-team-rbac.sh"
chmod +x "${TEAM_RBAC_SCRIPT}"

echo "Running grafana-team-rbac.sh"
./grafana-team-rbac.sh

echo "================================"
echo "Grafana TEAM RBAC Finished"
echo "================================"