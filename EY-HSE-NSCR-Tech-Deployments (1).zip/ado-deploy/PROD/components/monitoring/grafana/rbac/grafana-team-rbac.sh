#!/usr/bin/env bash

set -e
set -x

NAMESPACE="monitoring"
GRAFANA_URL="http://localhost:3000"

cleanup() {
    echo "Stopping Port Forward..."
    kill ${PF_PID} >/dev/null 2>&1 || true
}
trap cleanup EXIT

echo "================================="
echo "Starting Grafana Team/Folder RBAC"
echo "================================="

pwd
echo "==== teams.json ===="
cat teams.json

ADMIN_USER=$(kubectl -n ${NAMESPACE} get secret grafana-auth \
-o jsonpath='{.data.GF_SECURITY_ADMIN_USER}' | base64 -d)

ADMIN_PASS=$(kubectl -n ${NAMESPACE} get secret grafana-auth \
-o jsonpath='{.data.GF_SECURITY_ADMIN_PASSWORD}' | base64 -d)

echo "Starting port-forward..."
kubectl port-forward -n ${NAMESPACE} svc/grafana 3000:80 >/tmp/grafana-pf.log 2>&1 &
PF_PID=$!
sleep 15

curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/health"

rm -f /tmp/team_id_map.txt /tmp/dashboard_team_grants.txt /tmp/folder_team_grants.txt

# --- Function: create team if it doesn't already exist, return its ID ---
get_or_create_team() {
    local team_name="$1"
    local team_id
    team_id=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        "${GRAFANA_URL}/api/teams/search?name=$(echo "$team_name" | sed 's/ /%20/g')" \
        | jq -r '.teams[0].id // empty')


    if [[ -n "${team_id}" && "${team_id}" != "null" ]]; then
        echo "Team '${team_name}' already exists, id=${team_id}" >&2
        echo "${team_id}"
        return
    fi

    echo "Creating team '${team_name}'..." >&2
    local response
    response=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST "${GRAFANA_URL}/api/teams" \
        -H "Content-Type: application/json" \
        -d "{\"name\":\"${team_name}\"}")

    team_id=$(echo "${response}" | jq -r '.teamId // empty')
    if [[ -z "${team_id}" ]]; then
        echo "ERROR creating team '${team_name}': ${response}" >&2
        return 1
    fi
    echo "${team_id}"
}

# --- Function: sync a team's membership to exactly match the given email list ---
sync_team_members() {
    local team_id="$1"
    shift
    local target_emails=("$@")

    local current_members
    current_members=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        "${GRAFANA_URL}/api/teams/${team_id}/members")

    # Add anyone in the target list who isn't already a member
    for email in "${target_emails[@]}"; do
        local user_id
        user_id=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
            "${GRAFANA_URL}/api/users/lookup?loginOrEmail=${email}" | jq -r '.id // empty')

        if [[ -z "${user_id}" ]]; then
            echo "  WARNING: user '${email}' not found in Grafana (must log in via SSO at least once) — skipping"
            continue
        fi

        local already_member
        already_member=$(echo "${current_members}" | jq -r ".[] | select(.userId==${user_id}) | .userId")

        if [[ -n "${already_member}" ]]; then
            echo "  ${email} already in team"
        else
            curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
                -X POST "${GRAFANA_URL}/api/teams/${team_id}/members" \
                -H "Content-Type: application/json" \
                -d "{\"userId\":${user_id}}" > /dev/null
            echo "  Added ${email} to team"
        fi
    done

    # Remove anyone currently in the team who is NOT in the target list
    echo "${current_members}" | jq -c '.[]' | while read -r member; do
        local member_email
        member_email=$(echo "${member}" | jq -r '.email')
        local member_user_id
        member_user_id=$(echo "${member}" | jq -r '.userId')

        local should_stay="false"
        for email in "${target_emails[@]}"; do
            if [[ "${email,,}" == "${member_email,,}" ]]; then
                should_stay="true"
                break
            fi
        done

        if [[ "${should_stay}" == "false" ]]; then
            curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
                -X DELETE "${GRAFANA_URL}/api/teams/${team_id}/members/${member_user_id}" > /dev/null
            echo "  Removed ${member_email} from team (no longer in target list)"
        fi
    done
}

# --- Function: create folder if it doesn't already exist ---
get_or_create_folder() {
    local folder_title="$1"
    local folder_uid="$2"

    local existing_uid
    existing_uid=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        "${GRAFANA_URL}/api/search?type=dash-folder" \
        | jq -r ".[] | select(.title==\"${folder_title}\") | .uid" | head -1)

    if [[ -n "${existing_uid}" && "${existing_uid}" != "null" ]]; then
        echo "Folder '${folder_title}' already exists, uid=${existing_uid}" >&2
        echo "${existing_uid}"
        return
    fi

    echo "Creating folder '${folder_title}' (uid=${folder_uid})..." >&2
    local response
    response=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST "${GRAFANA_URL}/api/folders" \
        -H "Content-Type: application/json" \
        -d "{\"uid\":\"${folder_uid}\",\"title\":\"${folder_title}\"}")

    local new_uid
    new_uid=$(echo "${response}" | jq -r '.uid // empty')
    if [[ -z "${new_uid}" ]]; then
        echo "ERROR creating folder '${folder_title}': ${response}" >&2
        return 1
    fi
    echo "${new_uid}"
}

# --- Function: grant MULTIPLE teams' permissions on a folder in one call ---
# items_json should be like: [{"teamId":1,"permission":1},{"teamId":3,"permission":1}]
grant_team_folder_permission() {
    local folder_uid="$1"
    local items_json="$2"

    echo "Resetting folder to defaults before applying..."
    curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST "${GRAFANA_URL}/api/folders/${folder_uid}/permissions" \
        -H "Content-Type: application/json" \
        -d '{"items":[]}' > /dev/null

    local response
    response=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST "${GRAFANA_URL}/api/folders/${folder_uid}/permissions" \
        -H "Content-Type: application/json" \
        -d "{\"items\":${items_json}}")
    echo "${response}"
}

# --- Function: grant MULTIPLE teams' permissions on a specific dashboard in one call (by title) ---
# items_json should be like: [{"teamId":1,"permission":1},{"teamId":3,"permission":1}]
apply_dashboard_team_permissions() {
    local dashboard_title="$1"
    local items_json="$2"

    local all_dashboards

    all_dashboards=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search")

    local matches
    matches=$(echo "${all_dashboards}" | jq -r ".[] | select(.title==\"${dashboard_title}\") | .uid")
    local dash_uid
    dash_uid=$(echo "${matches}" | head -1)

    if [[ $(echo "${matches}" | grep -c .) -gt 1 ]]; then
        echo "  WARNING: multiple dashboards titled '${dashboard_title}' found, using first match: ${dash_uid}"
    fi

    if [[ -z "${dash_uid}" || "${dash_uid}" == "null" ]]; then
        echo "  Dashboard '${dashboard_title}' not found — skipping"
        return
    fi

    echo "  Resetting '${dashboard_title}' to defaults before applying..."
    curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST "${GRAFANA_URL}/api/dashboards/uid/${dash_uid}/permissions" \
        -H "Content-Type: application/json" \
        -d '{"items":[]}' > /dev/null

    local response
    response=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST "${GRAFANA_URL}/api/dashboards/uid/${dash_uid}/permissions" \
        -H "Content-Type: application/json" \
        -d "{\"items\":${items_json}}")

    echo "  ${dashboard_title} -> all teams -> ${response}"
}

# --- Pass 1: create/update every team and sync its membership ---
jq -c '.[]' teams.json | while read -r TEAM_ENTRY
do
    TEAM_NAME=$(echo "${TEAM_ENTRY}" | jq -r '.teamName')
    mapfile -t MEMBER_EMAILS < <(echo "${TEAM_ENTRY}" | jq -r '.members[]')

    echo "================================="

    echo "Team: ${TEAM_NAME}"
    echo "================================="

    TEAM_ID=$(get_or_create_team "${TEAM_NAME}")
    echo "TEAM_ID=${TEAM_ID}"
    echo "${TEAM_NAME}:${TEAM_ID}" >> /tmp/team_id_map.txt

    echo "Syncing members..."

    sync_team_members "${TEAM_ID}" "${MEMBER_EMAILS[@]}"

    FOLDER_TITLE=$(echo "${TEAM_ENTRY}" | jq -r '.folder.title // empty')
    if [[ -n "${FOLDER_TITLE}" ]]; then
        FOLDER_UID_HINT=$(echo "${TEAM_ENTRY}" | jq -r '.folder.uid // empty')
        FOLDER_UID=$(get_or_create_folder "${FOLDER_TITLE}" "${FOLDER_UID_HINT}")
        echo "FOLDER_UID=${FOLDER_UID}"
        PERMISSION=$(echo "${TEAM_ENTRY}" | jq -r '.permission')
        echo "${FOLDER_UID}|${TEAM_ID}|${PERMISSION}" >> /tmp/folder_team_grants.txt
    fi

    echo "Done with team ${TEAM_NAME}"
done

# --- Pass 1b: consolidate folder permissions across all teams that share a folder, apply once each ---
echo "================================="
echo "Consolidating folder permissions across all teams"
echo "================================="

if [[ -f /tmp/folder_team_grants.txt ]]; then
    cut -d'|' -f1 /tmp/folder_team_grants.txt | sort -u | while read -r FOLDER_UID; do
        ITEMS_JSON=$(grep "^${FOLDER_UID}|" /tmp/folder_team_grants.txt | awk -F'|' '{print "{\"teamId\":"$2",\"permission\":"$3"}"}' | jq -s -c '.')
        echo "Folder '${FOLDER_UID}' will receive combined grants: ${ITEMS_JSON}"
        grant_team_folder_permission "${FOLDER_UID}" "${ITEMS_JSON}"
    done
    rm -f /tmp/folder_team_grants.txt
fi

# --- Pass 2: build a combined items list PER DASHBOARD across all teams, then apply once each ---
echo "================================="
echo "Consolidating dashboard permissions across all teams"
echo "================================="

jq -c '.[]' teams.json | while read -r TEAM_ENTRY
do
    TEAM_NAME=$(echo "${TEAM_ENTRY}" | jq -r '.teamName')
    TEAM_ID=$(grep "^${TEAM_NAME}:" /tmp/team_id_map.txt | tail -1 | cut -d: -f2)
    PERMISSION=$(echo "${TEAM_ENTRY}" | jq -r '.permission')
    DASHBOARDS_JSON=$(echo "${TEAM_ENTRY}" | jq -c '.dashboards // empty')

    if [[ -n "${DASHBOARDS_JSON}" && "${DASHBOARDS_JSON}" != "null" ]]; then
        echo "${DASHBOARDS_JSON}" | jq -r '.[]' | while read -r DASH_TITLE; do
            echo "${DASH_TITLE}|${TEAM_ID}|${PERMISSION}" >> /tmp/dashboard_team_grants.txt
        done
    fi
done


if [[ -f /tmp/dashboard_team_grants.txt ]]; then

    cut -d'|' -f1 /tmp/dashboard_team_grants.txt | sort -u | while read -r DASH_TITLE; do
        ITEMS_JSON=$(grep "^${DASH_TITLE}|" /tmp/dashboard_team_grants.txt | awk -F'|' '{print "{\"teamId\":"$2",\"permission\":"$3"}"}' | jq -s -c '.')
        echo "Dashboard '${DASH_TITLE}' will receive combined grants: ${ITEMS_JSON}"
        apply_dashboard_team_permissions "${DASH_TITLE}" "${ITEMS_JSON}"
    done
    rm -f /tmp/dashboard_team_grants.txt
fi
rm -f /tmp/team_id_map.txt

echo "================================="
echo "Grafana Team/Folder RBAC Completed"
echo "================================="