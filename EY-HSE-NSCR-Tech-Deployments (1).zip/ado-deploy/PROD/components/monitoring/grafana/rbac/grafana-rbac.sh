#!/usr/bin/env bash

set -e
set -x

NAMESPACE="monitoring"
GRAFANA_URL="http://localhost:3000"

cleanup() {
    echo "Stopping Port Forward..."
    kill ${PF_PID} >/dev/null 2>&1 || true
}

trap cleanup EXIT

echo "================================="
echo "Starting Grafana RBAC"
echo "================================="

pwd

echo "Listing RBAC files..."
ls -ltr

echo "==== folders.json ===="
cat folders.json

if [ -f dashboards.json ]; then
    echo "==== dashboards.json ===="
    cat dashboards.json
fi

echo "Checking jq..."
which jq || true
jq --version || true

echo "Grafana Services:"
kubectl get svc -n ${NAMESPACE}

ADMIN_USER=$(kubectl -n ${NAMESPACE} get secret grafana-auth \
-o jsonpath='{.data.GF_SECURITY_ADMIN_USER}' | base64 -d)

ADMIN_PASS=$(kubectl -n ${NAMESPACE} get secret grafana-auth \
-o jsonpath='{.data.GF_SECURITY_ADMIN_PASSWORD}' | base64 -d)

echo "Starting port-forward..."

kubectl port-forward -n ${NAMESPACE} svc/grafana 3000:80 >/tmp/grafana-pf.log 2>&1 &
PF_PID=$!

sleep 15

echo "Testing Grafana API..."

curl -s \
-u "${ADMIN_USER}:${ADMIN_PASS}" \
${GRAFANA_URL}/api/health

echo "================================="
echo "Applying Folder Permissions..."
echo "================================="

jq -c '.[]' folders.json | while read FOLDER
do
    FOLDER_NAME=$(echo "$FOLDER" | jq -r '.title')
    PERMISSIONS_JSON=$(echo "$FOLDER" | jq -c '.permissions // empty')
    ROLES_JSON=$(echo "$FOLDER" | jq -c '.roles // empty')
    ROLE=$(echo "$FOLDER" | jq -r '.role // empty')
    PERMISSION=$(echo "$FOLDER" | jq -r '.permission // empty')

    echo "Folder=${FOLDER_NAME}"

    FOLDER_UID=$(curl -s \
    -u "${ADMIN_USER}:${ADMIN_PASS}" \
    "${GRAFANA_URL}/api/search?type=dash-folder" \
    | jq -r ".[] | select(.title==\"${FOLDER_NAME}\") | .uid" \
    | head -1)

    echo "FOLDER_UID=${FOLDER_UID}"

    if [[ -z "${FOLDER_UID}" || "${FOLDER_UID}" == "null" ]]; then
        echo "Folder not found"
        continue
    fi

    echo "Resetting folder to defaults before applying..."
    curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
    -X POST \
    "${GRAFANA_URL}/api/folders/${FOLDER_UID}/permissions" \
    -H "Content-Type: application/json" \
    -d '{"items":[]}' > /dev/null

    if [[ -n "${PERMISSIONS_JSON}" && "${PERMISSIONS_JSON}" != "null" ]]; then
        echo "Permissions=${PERMISSIONS_JSON}"
        ITEMS="${PERMISSIONS_JSON}"
    elif [[ -n "${ROLES_JSON}" && "${ROLES_JSON}" != "null" ]]; then
        echo "Roles=${ROLES_JSON}"
        ITEMS=$(echo "${ROLES_JSON}" | jq -c "[.[] | {role: ., permission: ${PERMISSION}}]")
    elif [[ -n "${ROLE}" ]]; then
        echo "Role=${ROLE}"
        ITEMS="[{\"role\":\"${ROLE}\",\"permission\":${PERMISSION}}]"
    else
        echo "No permissions/roles/role defined for folder ${FOLDER_NAME}, skipping"
        continue
    fi

    RESPONSE=$(curl -s \
    -u "${ADMIN_USER}:${ADMIN_PASS}" \
    -X POST \
    "${GRAFANA_URL}/api/folders/${FOLDER_UID}/permissions" \
    -H "Content-Type: application/json" \
    -d "{\"items\":${ITEMS}}")

    echo "${RESPONSE}"
    echo "Folder permissions updated"
done

echo "================================="
echo "Applying Dashboard Permissions..."
echo "================================="

if [ -f dashboards.json ]; then

    ALL_DASHBOARDS=$(curl -s \
    -u "${ADMIN_USER}:${ADMIN_PASS}" \
    "${GRAFANA_URL}/api/search")

    echo "All Dashboards:"

    echo "${ALL_DASHBOARDS}" \
    | jq '.[] | {
        title,
        folderTitle,
        uid
    }'

    jq -c '.[]' dashboards.json | while read DASHBOARD
    do
        FOLDER_NAME=$(echo "$DASHBOARD" | jq -r '.folder // empty')
        DASHBOARD_NAME=$(echo "$DASHBOARD" | jq -r '.dashboard')
        PERMISSIONS_JSON=$(echo "$DASHBOARD" | jq -c '.permissions // empty')
        ROLES_JSON=$(echo "$DASHBOARD" | jq -c '.roles // empty')
        ROLE=$(echo "$DASHBOARD" | jq -r '.role // empty')
        PERMISSION=$(echo "$DASHBOARD" | jq -r '.permission // empty')
        USER_EMAILS_JSON=$(echo "$DASHBOARD" | jq -c '.userEmails // empty')

        echo "Folder=${FOLDER_NAME}"
        echo "Dashboard=${DASHBOARD_NAME}"

        if [[ -n "${FOLDER_NAME}" ]]; then
            DASHBOARD_UID=$(echo "${ALL_DASHBOARDS}" \
            | jq -r ".[] |
            select(
                .title==\"${DASHBOARD_NAME}\" and
                .folderTitle==\"${FOLDER_NAME}\"
            ) |
            .uid" \
            | head -1)
        else
            DASHBOARD_MATCHES=$(echo "${ALL_DASHBOARDS}" \
            | jq -r ".[] | select(.title==\"${DASHBOARD_NAME}\") | .uid")

            DASHBOARD_UID=$(echo "${DASHBOARD_MATCHES}" | head -1)

            if [[ $(echo "${DASHBOARD_MATCHES}" | grep -c .) -gt 1 ]]; then
                echo "WARNING: multiple dashboards titled '${DASHBOARD_NAME}' found. Add a 'folder' key in dashboards.json to disambiguate. Using first match: ${DASHBOARD_UID}"
            fi
        fi

        if [[ -z "${DASHBOARD_UID}" ]]; then
            echo "Available dashboards:"
            echo "${ALL_DASHBOARDS}" \
            | jq -r '.[] | "\(.folderTitle) -> \(.title)"'
        fi

        echo "DASHBOARD_UID=${DASHBOARD_UID}"

        if [[ -z "${DASHBOARD_UID}" || "${DASHBOARD_UID}" == "null" ]]; then
            echo "Dashboard not found"
            continue
        fi

        DASHBOARD_ID=$(curl -s \
        -u "${ADMIN_USER}:${ADMIN_PASS}" \
        "${GRAFANA_URL}/api/dashboards/uid/${DASHBOARD_UID}" \
        | jq -r '.dashboard.id')

        echo "DASHBOARD_ID=${DASHBOARD_ID}"

        if [[ -z "${DASHBOARD_ID}" || "${DASHBOARD_ID}" == "null" ]]; then
            echo "Dashboard ID not found"
            continue
        fi

        echo "Resetting dashboard to defaults before applying..."
        curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST \
        "${GRAFANA_URL}/api/dashboards/id/${DASHBOARD_ID}/permissions" \
        -H "Content-Type: application/json" \
        -d '{"items":[]}' > /dev/null

        if [[ -n "${PERMISSIONS_JSON}" && "${PERMISSIONS_JSON}" != "null" ]]; then
            echo "Permissions=${PERMISSIONS_JSON}"
            ITEMS="${PERMISSIONS_JSON}"
        elif [[ -n "${ROLES_JSON}" && "${ROLES_JSON}" != "null" ]]; then
            echo "Roles=${ROLES_JSON}"
            ITEMS=$(echo "${ROLES_JSON}" | jq -c "[.[] | {role: ., permission: ${PERMISSION}}]")
        elif [[ -n "${ROLE}" ]]; then
            echo "Role=${ROLE}"
            ITEMS="[{\"role\":\"${ROLE}\",\"permission\":${PERMISSION}}]"
        else
            ITEMS="[]"
        fi

        if [[ -n "${USER_EMAILS_JSON}" && "${USER_EMAILS_JSON}" != "null" ]]; then
            echo "UserEmails=${USER_EMAILS_JSON}"
            USER_ITEMS="[]"
            while read -r USER_ENTRY; do
                USER_EMAIL=$(echo "$USER_ENTRY" | jq -r '.email')
                USER_PERMISSION=$(echo "$USER_ENTRY" | jq -r '.permission')
                USER_ID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" \
                    "${GRAFANA_URL}/api/users/lookup?loginOrEmail=${USER_EMAIL}" | jq -r '.id // empty')
                if [[ -z "${USER_ID}" ]]; then
                    echo "  WARNING: user '${USER_EMAIL}' not found in Grafana (must log in via SSO at least once first) — skipping"
                    continue
                fi
                echo "  Resolved ${USER_EMAIL} -> userId ${USER_ID}"
                USER_ITEMS=$(echo "${USER_ITEMS}" | jq -c ". + [{\"userId\":${USER_ID},\"permission\":${USER_PERMISSION}}]")
            done < <(echo "${USER_EMAILS_JSON}" | jq -c '.[]')
            ITEMS=$(jq -c -n --argjson base "${ITEMS}" --argjson users "${USER_ITEMS}" '$base + $users')
        fi

        if [[ "${ITEMS}" == "[]" ]]; then
            echo "No permissions/roles/role/userEmails defined for dashboard ${DASHBOARD_NAME}, skipping"
            continue
        fi

        RESPONSE=$(curl -s \
        -u "${ADMIN_USER}:${ADMIN_PASS}" \
        -X POST \
        "${GRAFANA_URL}/api/dashboards/id/${DASHBOARD_ID}/permissions" \
        -H "Content-Type: application/json" \
        -d "{\"items\":${ITEMS}}")

        echo "${RESPONSE}"
        echo "Dashboard permissions updated"
    done

else
    echo "dashboards.json not found"
fi

echo "================================="
echo "Grafana RBAC Completed"
echo "================================="