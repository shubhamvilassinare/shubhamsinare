#!/usr/bin/env bash
set -euo pipefail

NS="${NS:-monitoring}"
RELEASE="${RELEASE:-k8s-monitoring}"
CHART="${CHART:-grafana/k8s-monitoring}"
CHART_VERSION="${CHART_VERSION:-3.8.5}"
VALUES_FILE="${VALUES_FILE:-${BUILD_SOURCESDIRECTORY:-$PWD}/ado-deploy/${ENVIRONMENT:-PROD}/components/monitoring/alloy/k8s-monitoring-helm-values.yaml}"

SIDECAR_INDEX=1
PATCH_JSON='[{"op":"add","path":"/spec/template/spec/containers/'"$SIDECAR_INDEX"'/securityContext","value":{"runAsNonRoot":false,"runAsUser":65534,"runAsGroup":65534}}]'

# Tools & values
[[ -f "$VALUES_FILE" ]] || { echo "[ERROR] Values not found: $VALUES_FILE"; exit 1; }
command -v helm >/dev/null || { echo "[ERROR] helm missing"; exit 1; }
command -v kubectl >/dev/null || { echo "[ERROR] kubectl missing"; exit 1; }

echo "[INFO] Checking Helm release lock..."
if helm status k8s-monitoring -n monitoring 2>&1 | grep -q 'pending'; then
    echo "[WARN] Helm release locked; forcing cleanup"
    helm rollback k8s-monitoring 0 -n monitoring || true
    kubectl delete secret -n monitoring -l "owner=helm,name=k8s-monitoring" || true
fi

# Namespace & repo
kubectl create ns "$NS" --dry-run=client -o yaml | kubectl apply -f -
helm repo add grafana https://grafana.github.io/helm-charts >/dev/null || true
helm repo update >/dev/null || echo "[WARN] helm repo update failed/timeout, continuing..."

if ! helm upgrade -i "$RELEASE" "$CHART" -n "$NS" -f "$VALUES_FILE" --version "$CHART_VERSION" --no-hooks --set cluster.name="${AKS_NAME}" --set podLogs.structuredMetadata=null; then
    echo "[ERROR] Helm upgrade failed"

    echo "===== DEBUG: JOBS ====="
    kubectl get jobs -n "$NS" || true

    echo "===== DEBUG: JOB LOGS (add-finalizer) ====="
    kubectl logs job/k8s-monitoring-add-finalizer -n "$NS" --tail=200 || true

    echo "===== DEBUG: PODS ====="
    kubectl get pods -n "$NS" || true

    echo "===== DEBUG: EVENTS ====="
    kubectl get events -n "$NS" --sort-by=.metadata.creationTimestamp | tail -40 || true

    exit 1
fi

echo "===== DEBUG-DEEP: All Alloy Pods ====="
kubectl get pods -n "$NS" -o wide || true

echo "===== DEBUG-DEEP: Describe All Alloy Pods ====="
for p in $(kubectl get pods -n "$NS" -l app.kubernetes.io/name -o jsonpath='{.items[*].metadata.name}'); do
  echo "--- DESCRIBE POD: $p ---"
  kubectl describe pod "$p" -n "$NS" || true
done

echo "===== DEBUG-DEEP: Alloy Logs Pod Logs ====="
for p in $(kubectl get pods -n "$NS" | grep alloy-logs | awk '{print $1}'); do
  echo "--- LOGS: $p ---"
  kubectl logs "$p" -n "$NS" --all-containers --tail=200 || true
done

echo "===== DEBUG-DEEP: Alloy Metrics Pod Logs ====="
for p in $(kubectl get pods -n "$NS" | grep alloy-metrics | awk '{print $1}'); do
  echo "--- LOGS: $p ---"
  kubectl logs "$p" -n "$NS" --all-containers --tail=200 || true
done

echo "===== DEBUG-DEEP: Alloy Singleton Pod Logs ====="
for p in $(kubectl get pods -n "$NS" | grep alloy-singleton | awk '{print $1}'); do
  echo "--- LOGS: $p ---"
  kubectl logs "$p" -n "$NS" --all-containers --tail=200 || true
done

echo "===== DEBUG-DEEP: OPA / Gatekeeper Denials ====="
kubectl get events -n "$NS" --sort-by=.lastTimestamp | grep -i deny -A3 -B3 || true

echo "===== DEBUG-DEEP: Full Event Log ====="
kubectl get events -n "$NS" --sort-by=.lastTimestamp || true

echo "===== DEBUG-DEEP: Alloy Operator Logs ====="
OP=$(kubectl get pod -n "$NS" -l app.kubernetes.io/name=alloy-operator -o jsonpath='{.items[0].metadata.name}')
kubectl logs "$OP" -n "$NS" --tail=200 || true

echo "===== DEBUG-DEEP: DS / STS / DEPLOY ====="
kubectl get ds,sts,deploy -n "$NS" || true

# Wait until Operator recreates workloads (max 2 min)
echo "[INFO] Waiting for Alloy workloads to exist..."
end=$((SECONDS+120))
while (( SECONDS < end )); do
    ds=$(kubectl get ds -n "$NS" k8s-monitoring-alloy-logs --no-headers 2>/dev/null || true)
    sts=$(kubectl get sts -n "$NS" k8s-monitoring-alloy-metrics --no-headers 2>/dev/null || true)
    dep=$(kubectl get deploy -n "$NS" k8s-monitoring-alloy-singleton --no-headers 2>/dev/null || true)
    [[ -n "$ds" && -n "$sts" && -n "$dep" ]] && break
    sleep 4
done

kubectl get ds,sts,deploy -n "$NS" | grep -E 'alloy-(logs|metrics|singleton)' || true

# Patch config-reloader securityContext
echo "[INFO] Patching sidecar securityContext (config-reloader)"
for res in \
    deploy/k8s-monitoring-alloy-singleton \
    daemonset/k8s-monitoring-alloy-logs \
    statefulset/k8s-monitoring-alloy-metrics
do
    kubectl patch "$res" -n "$NS" --type json -p "$PATCH_JSON" || echo "[WARN] Patch failed for $res"
done

# Rollout restart & short wait (best-effort)
kubectl rollout restart deploy k8s-monitoring-alloy-singleton -n "$NS" || true
kubectl rollout restart daemonset k8s-monitoring-alloy-logs -n "$NS" || true
kubectl rollout restart statefulset k8s-monitoring-alloy-metrics -n "$NS" || true

kubectl rollout status deploy k8s-monitoring-alloy-singleton -n "$NS" --timeout=4m || true
kubectl rollout status daemonset k8s-monitoring-alloy-logs -n "$NS" --timeout=4m || true
kubectl rollout status statefulset k8s-monitoring-alloy-metrics -n "$NS" --timeout=6m || true

# Verify sidecar effective settings
echo "[INFO] Verifying config-reloader securityContext"
kubectl get pods -n "$NS" -l 'app.kubernetes.io/name in (alloy-logs,alloy-metrics,alloy-singleton)' -o json \
| jq -r '.items[] as $p | $p.spec.containers[] | select(.name=="config-reloader") |
        "\($p.metadata.name): runAsNonRoot=\(.securityContext.runAsNonRoot) runAsUser=\(.securityContext.runAsUser) runAsGroup=\(.securityContext.runAsGroup)"' || true

echo "[DONE] Alloy deployed; sidecar patched."