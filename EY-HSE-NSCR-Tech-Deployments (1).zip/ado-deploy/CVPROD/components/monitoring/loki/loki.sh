#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="monitoring"
RELEASE="loki"
CHART="grafana/loki"
CHART_VERSION="6.46.0"
CHART_REPO="https://grafana.github.io/helm-charts"
VALUES_FILE="${BUILD_SOURCESDIRECTORY}/ado-deploy/${ENVIRONMENT}/components/monitoring/loki/loki-helm-values.yaml"

[[ -f "$VALUES_FILE" ]] || { echo "[ERROR] Missing values file: $VALUES_FILE"; exit 1; }

# Ensure namespace exists
kubectl create ns "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# Debug status BEFORE installation
echo "===== DEBUG: POD STATUS ====="
kubectl get pods -n "${NAMESPACE}" || true

echo "===== DEBUG: DESCRIBE PODS ====="
kubectl describe pods -n "${NAMESPACE}" || true

echo "===== DEBUG: EVENTS ====="
kubectl get events -n "${NAMESPACE}" --sort-by=.metadata.creationTimestamp || true

# Helm repo
helm repo add grafana "$CHART_REPO" >/dev/null || true
helm repo update >/dev/null

echo "[INFO] Installing/Upgrading Loki..."
helm upgrade -i "$RELEASE" "$CHART" \
    -n "$NAMESPACE" \
    -f "$VALUES_FILE" \
    --version "$CHART_VERSION"

# --- StatefulSet check ---
echo "[INFO] Waiting for Loki StatefulSet..."
LOKI_STS=$(kubectl get sts -n "${NAMESPACE}" \
  --no-headers | grep loki | awk '{print $1}' || true)

if [[ -z "${LOKI_STS}" ]]; then
    echo "[WARN] Loki StatefulSet not found, skipping wait..."
else
    kubectl rollout status statefulset "${LOKI_STS}" -n "${NAMESPACE}" --timeout=10m || true
fi

# --- Pod readiness check ---
echo "[INFO] Waiting for Loki pods readiness..."
LOKI_POD=$(kubectl get pods -n "${NAMESPACE}" \
  --no-headers | grep loki | awk '{print $1}' || true)

if [[ -z "${LOKI_POD}" ]]; then
    echo "[WARN] Loki pod not found, skipping readiness wait..."
    kubectl get pods -n "${NAMESPACE}"
else
    kubectl wait --for=condition=Ready pod "${LOKI_POD}" -n "${NAMESPACE}" --timeout=600s || {
        echo "[WARN] Loki pod not ready after timeout. Current status:"
        kubectl get pods -n "${NAMESPACE}" -o wide
    }
fi

echo "[INFO] Loki deployment completed:"
kubectl get pods,svc,statefulset,pvc -n "${NAMESPACE}" | grep loki || true