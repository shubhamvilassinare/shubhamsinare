# Important

Because we are using flux substitutions, we need to change `${datasource}` to `$${datasource}`.

When adding new dashboards replace `${` with `$${`
