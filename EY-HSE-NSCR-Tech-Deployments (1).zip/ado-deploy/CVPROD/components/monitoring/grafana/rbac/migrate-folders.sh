# #!/usr/bin/env bash

# set -e

# NAMESPACE="monitoring"
# GRAFANA_URL="http://localhost:3000"

# cleanup() {
#     echo "Stopping Port Forward..."
#     kill ${PF_PID} >/dev/null 2>&1 || true
# }
# trap cleanup EXIT

# echo "================================="
# echo "One-time folder migration"
# echo "================================="

# ADMIN_USER=$(kubectl -n ${NAMESPACE} get secret pprd-grafana-auth -o jsonpath='{.data.GF_SECURITY_ADMIN_USER}' | base64 -d)
# ADMIN_PASS=$(kubectl -n ${NAMESPACE} get secret pprd-grafana-auth -o jsonpath='{.data.GF_SECURITY_ADMIN_PASSWORD}' | base64 -d)

# kubectl port-forward -n ${NAMESPACE} svc/grafana 3000:80 >/tmp/grafana-pf.log 2>&1 &
# PF_PID=$!
# sleep 15

# echo "Renaming Persistence-Test -> Viewer"
# PT_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?type=dash-folder" | jq -r '.[] | select(.title=="Persistence-Test") | .uid')
# if [[ -n "${PT_UID}" && "${PT_UID}" != "null" ]]; then
#     PT_VERSION=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/folders/${PT_UID}" | jq -r '.version')
#     curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" -X PUT "${GRAFANA_URL}/api/folders/${PT_UID}" \
#       -H "Content-Type: application/json" \
#       -d "{\"title\":\"Viewer\",\"version\":${PT_VERSION},\"overwrite\":true}"
#     echo "Done."
# else
#     echo "Persistence-Test not found, skipping (already renamed?)"
# fi

# echo "Renaming Kubernetes -> Editor"
# K8S_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?type=dash-folder" | jq -r '.[] | select(.title=="Kubernetes") | .uid')
# if [[ -n "${K8S_UID}" && "${K8S_UID}" != "null" ]]; then
#     K8S_VERSION=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/folders/${K8S_UID}" | jq -r '.version')
#     curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" -X PUT "${GRAFANA_URL}/api/folders/${K8S_UID}" \
#       -H "Content-Type: application/json" \
#       -d "{\"title\":\"Editor\",\"version\":${K8S_VERSION},\"overwrite\":true}"
#     echo "Done."
# else
#     echo "Kubernetes not found, skipping (already renamed?)"
# fi

# echo "Moving 'SLA & Performance' dashboard into Editor folder"
# SLA_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search" | jq -r '.[] | select(.title=="SLA & Performance") | .uid')
# if [[ -n "${SLA_UID}" && "${SLA_UID}" != "null" ]]; then
#     SLA_JSON=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/dashboards/uid/${SLA_UID}" | jq '.dashboard')
#     EDITOR_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?type=dash-folder" | jq -r '.[] | select(.title=="Editor") | .uid')
#     curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" -X POST "${GRAFANA_URL}/api/dashboards/db" \
#       -H "Content-Type: application/json" \
#       -d "$(jq -n --argjson dash "${SLA_JSON}" --arg folderUid "${EDITOR_UID}" '{dashboard: $dash, folderUid: $folderUid, overwrite: true}')"
#     echo "Done."
# else
#     echo "SLA & Performance not found, skipping"
# fi

# echo "================================="
# echo "Migration complete"
# echo "================================="