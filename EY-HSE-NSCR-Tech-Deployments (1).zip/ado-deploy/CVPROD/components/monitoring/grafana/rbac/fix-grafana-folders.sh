# #!/usr/bin/env bash
# set -e

# NAMESPACE="monitoring"
# GRAFANA_URL="http://localhost:3000"

# cleanup() {
#     echo "Stopping Port Forward..."
#     kill ${PF_PID} >/dev/null 2>&1 || true
# }
# trap cleanup EXIT

# echo "================================="
# echo "Cleaning up leftover Persistence-Test folder"
# echo "================================="

# ADMIN_USER=$(kubectl -n ${NAMESPACE} get secret pprd-grafana-auth -o jsonpath='{.data.GF_SECURITY_ADMIN_USER}' | base64 -d)
# ADMIN_PASS=$(kubectl -n ${NAMESPACE} get secret pprd-grafana-auth -o jsonpath='{.data.GF_SECURITY_ADMIN_PASSWORD}' | base64 -d)

# kubectl port-forward -n ${NAMESPACE} svc/grafana 3000:80 >/tmp/grafana-pf.log 2>&1 &
# PF_PID=$!
# sleep 15

# curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/health" || { echo "Grafana not reachable"; exit 1; }
# echo ""

# VIEWER_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?type=dash-folder" | jq -r '.[] | select(.title=="Viewer") | .uid')
# EDITOR_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?type=dash-folder" | jq -r '.[] | select(.title=="Editor") | .uid')

# echo "Step 1: Moving stray dashboards out of Persistence-Test"

# move_dashboard() {
#     local title="$1"
#     local target_uid="$2"
#     local uid
#     uid=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search" \
#         | jq -r --arg t "$title" '.[] | select(.title==$t and .folderTitle=="Persistence-Test") | .uid' | head -1)
#     if [[ -z "$uid" || "$uid" == "null" ]]; then
#         echo "  '$title' not found in Persistence-Test — skipping"
#         return
#     fi
#     local dash
#     dash=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/dashboards/uid/${uid}" | jq '.dashboard')
#     curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" -X POST "${GRAFANA_URL}/api/dashboards/db" \
#         -H "Content-Type: application/json" \
#         -d "$(jq -n --argjson d "$dash" --arg f "$target_uid" '{dashboard:$d, folderUid:$f, overwrite:true}')" > /dev/null
#     echo "  Moved '$title'"
# }

# move_dashboard "SLA & Performance" "${EDITOR_UID}"
# move_dashboard "Test Dashboard" "${VIEWER_UID}"
# echo ""

# echo "Step 2: Deleting duplicate 'Usage Summary Main' (uid ad57djtt) in Persistence-Test"
# DUP_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search" \
#     | jq -r '.[] | select(.title=="Usage Summary Main" and .folderTitle=="Persistence-Test") | .uid')
# if [[ -n "$DUP_UID" && "$DUP_UID" != "null" ]]; then
#     curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" -X DELETE "${GRAFANA_URL}/api/dashboards/uid/${DUP_UID}" > /dev/null
#     echo "  Deleted duplicate uid=${DUP_UID}"
# else
#     echo "  No duplicate found in Persistence-Test — skipping"
# fi
# echo ""

# echo "Step 3: Deleting empty leftover folders (nested Kubernetes, then Persistence-Test)"

# NESTED_K8S_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?type=dash-folder" | jq -r '.[] | select(.title=="Kubernetes") | .uid')
# PERSISTENCE_TEST_UID=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?type=dash-folder" | jq -r '.[] | select(.title=="Persistence-Test") | .uid')

# delete_if_empty() {
#     local folder_uid="$1"
#     local folder_name="$2"
#     if [[ -z "$folder_uid" || "$folder_uid" == "null" ]]; then
#         echo "  '$folder_name' not found — skipping"
#         return
#     fi
#     local remaining
#     remaining=$(curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search?folderUIDs=${folder_uid}" | jq 'length')
#     if [[ "$remaining" -gt 0 ]]; then
#         echo "  '$folder_name' still has ${remaining} item(s) — NOT deleting. Check manually."
#         return
#     fi
#     curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" -X DELETE "${GRAFANA_URL}/api/folders/${folder_uid}" > /dev/null
#     echo "  Deleted empty folder '$folder_name'"
# }

# delete_if_empty "${NESTED_K8S_UID}" "Kubernetes"
# delete_if_empty "${PERSISTENCE_TEST_UID}" "Persistence-Test"
# echo ""

# echo "================================="
# echo "Final state"
# echo "================================="
# curl -s -u "${ADMIN_USER}:${ADMIN_PASS}" "${GRAFANA_URL}/api/search" \
#     | jq -r '.[] | select(.type=="dash-db") | "\(.folderTitle // "General") -> \(.title)"' | sort

# echo ""
# echo "Done"