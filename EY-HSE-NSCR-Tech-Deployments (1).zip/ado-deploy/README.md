# NSCR Azure Pipelines

This README describes two Azure Pipelines for NSCR deployments:

1. **App Deploy Pipeline** (`azure-pipeline-app-deploy.yaml`): Deploys application services (e.g., abac, auditor, portal, etc.)
2. **Components Deploy Pipeline** (`azure-pipeline-components-deploy.yaml`): Deploys infrastructure components (e.g., external-secrets, haproxy-controller, opensearch, reloader)

---

## 1. App Deploy Pipeline

**Pipeline file:** `azure-pipeline-app-deploy.yaml`

### Overview
- Manual trigger only (`trigger: none`, `pr: none`)
- Uses a self-hosted Linux agent (`LinuxSelfHostedAgent`)
- Deploys selected app services to DEV, PREPROD, or PROD

### Parameters
- `environment`: Target environment (`DEV`, `PREPROD`, `PROD`)
- `service`: Service to deploy (`ALL` for all except Keycloak, or a specific service)

### Variables
- Paths for environment, configs, Helm values, service list, and versions
- Variable groups for secrets/configuration per environment

### Stages & Steps
1. **Checkout Repository**
2. **Install Helm & Kubectl**
3. **Install yq** (YAML processor)
4. **Replace Variables**
   - Loads env vars from configmap
   - Replaces variables in Helm YAMLs and config files using `envsubst` and `yq`
   - Handles hardcoded value replacements for each environment
   - Updates external secrets YAML
5. **Apply Kustomize**
   - Copies kustomization/configmap files
   - Runs `kubectl`
6. **Deploy Services**
   - If `ALL`: Deploys all services except Keycloak
   - If `keycloak`: Deploys Keycloak Helm chart
   - If specific service: Deploys only that service

### Example Pipeline Run
- Deploy all services to DEV:
  - `environment`: DEV
  - `service`: ALL
- Deploy only Keycloak:
  - `environment`: DEV
  - `service`: keycloak

---

## 2. Components Deploy Pipeline

**Pipeline file:** `azure-pipeline-components-deploy.yaml`

### Overview
- Manual trigger only (`trigger: none`, `pr: none`)
- Uses a self-hosted Linux agent (`LinuxSelfHostedAgent`)
- Deploys selected infrastructure components to PREPROD or PROD

### Parameters
- `environment`: Target environment (`PREPROD`, `PROD`)
- `service`: Component to deploy (`external-secrets`, `haproxy-controller`, `opensearch`, `reloader`)
- `deployService`: Whether to deploy the service (default: true)
- `updateDockerSecret`: Whether to update Docker registry secret (default: false)

### Variables
- Paths for environment and service
- Variable groups for secrets/configuration per environment

### Stages & Steps
1. **Checkout Repository**
2. **Install Helm & Kubectl**
3. **Helm Login**
4. **Deploy Service** (conditional)
   - For each component, applies namespace/configmap/CRDs as needed
   - Installs/updates Helm chart for the component
5. **Update Docker Secret** (conditional)
   - Deletes and recreates Docker registry secret in the namespace

### Usage Notes
- Use `service` parameter to select which component to deploy
- Use `deployService` and `updateDockerSecret` to control deployment steps
- Helm charts and CRDs are managed per component

### Example Pipeline Run
- Deploy external-secrets to PREPROD:
  - `environment`: PREPROD
  - `service`: external-secrets
  - `deployService`: true
- Update Docker secret for haproxy-controller in PROD:
  - `environment`: PROD
  - `service`: haproxy-controller
  - `updateDockerSecret`: true
